<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Contacto extends Model
{
    protected $fillable = ['persona_dni','contacto_nombre','relacion','celular'];

//    persona
}
