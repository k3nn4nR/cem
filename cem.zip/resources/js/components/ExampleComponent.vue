<template>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">Example Component</div>
                    <div class="card-body">
                        
                    </div>
                    <div class="card-footer">
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import Seguimientos from './Seguimientos.vue';
    import Casos from './Casos.vue';
    import Personas from './Personas.vue';
    import Personal from './Personal.vue';
    export default {
        components:{
            Seguimientos,
            Casos,
            Personas,
            Personal,
        },
        mounted() {

        },
        methods:{

        }
    }
</script>
