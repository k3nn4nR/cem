@extends('layouts.app')

@section('content')
<personal-component/>
@endsection
