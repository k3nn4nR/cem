@extends('layouts.app')

@section('content')
<caso-component/>
@endsection
