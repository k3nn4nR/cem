@extends('layouts.app')

@section('content')
<seguimiento-component/>
@endsection
