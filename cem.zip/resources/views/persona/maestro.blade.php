@extends('layouts.app')

@section('content')
<persona-component/>
@endsection
