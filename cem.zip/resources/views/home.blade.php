@extends('layouts.app')

@section('content')
<example-component></example-component>
@endsection
